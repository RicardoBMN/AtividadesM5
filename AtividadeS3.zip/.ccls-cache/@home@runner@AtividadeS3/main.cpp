#include <iostream>
#include <unordered_map>
#include <string>
#include <cassert>

class DHTNode {
public:
    std::unordered_map<std::string, std::string> store;

    void put(const std::string& key, const std::string& value) {
        store[key] = value;
    }

    std::string get(const std::string& key) {
        if (store.find(key) != store.end()) {
            return store[key];
        }
        return "Key not found";
    }

    void remove(const std::string& key) {
        store.erase(key);
    }
};

int main() {
    DHTNode node;
    // Teste 1: Inserção de um par chave-valor
    node.put("chave1", "valor1");
    // Teste 2: Recuperação de um valor
    assert(node.get("chave1") == "valor1");
    // Teste 3: Chave inexistente
    assert(node.get("chave_inexistente") == "Key not found");
    // Teste 4: Remoção de um par chave-valor
    node.remove("chave1");
    assert(node.get("chave1") == "Key not found");
    // Teste 5: Atualização de um valor
    node.put("chave2", "valor2");
    node.put("chave2", "valor2_atualizado");
    assert(node.get("chave2") == "valor2_atualizado");

    std::cout << "Todos os testes passaram!" << std::endl;

    return 0;
}
